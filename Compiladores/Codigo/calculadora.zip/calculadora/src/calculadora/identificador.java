/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package calculadora;

/**
 *
 * @author solop
 */
public class identificador {
    public String linea;
    public String token;
    public String lexema;
}
