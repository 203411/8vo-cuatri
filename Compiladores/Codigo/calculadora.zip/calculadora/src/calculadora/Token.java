/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package calculadora;

/**
 *
 * @author solop
 */
public enum Token {
    Numero,
    PLUS,
    TAKE,
    TIMES,
    DIVIDE,
    OPENPAR,
    CLOSEPAR,
    ERROR
}
