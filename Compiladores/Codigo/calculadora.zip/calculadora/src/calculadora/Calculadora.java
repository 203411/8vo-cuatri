
package calculadora;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author solop
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        String ruta1 = "C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/Lexer.flex";
        String ruta2 = "C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/LexerCup.flex";
        String[] rutaSin = {"-parser", "Sintax", "C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/Sintax.cup"};
        
        generarLexer(ruta1, ruta2, rutaSin);
        interfaz win = new interfaz();
        win.setVisible(true);
    }
    
    public static void generarLexer(String ruta1, String ruta2, String[] rutaSin) throws IOException, Exception{
        File archivo;
        archivo = new File(ruta1);
        JFlex.Main.generate(archivo);
        archivo = new File(ruta2);
        JFlex.Main.generate(archivo);
        java_cup.Main.main(rutaSin);
            
        Path rutaSym = Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/sym.java");
        if (Files.exists(rutaSym)) {
            Files.delete(rutaSym);
        }
        Files.move(
          Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/sym.java"),
          Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/sym.java")
        );
            
            
        Path rutaSintax = Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/Sintax.java");
        if (Files.exists(rutaSintax)) {
            Files.delete(rutaSintax);
        }
        Files.move(
          Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/Sintax.java"),
          Paths.get("C:/Users/solop/Documents/NetBeansProjects/calculadora/src/calculadora/Sintax.java")
        );     
    }
    
}
