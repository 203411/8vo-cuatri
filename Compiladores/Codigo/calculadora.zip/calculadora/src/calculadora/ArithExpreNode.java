package calculadora;
/**
 *
 * @author solop
 */
public class ArithExpreNode {
    String operation;  
    ArithExpreNode left;  
    ArithExpreNode right; 
    int value;  

    public ArithExpreNode(String op, ArithExpreNode l, ArithExpreNode r) {
        this.operation = op;
        this.left = l;
        this.right = r;
    }

    public ArithExpreNode(int val) {
        this.value = val;
    }

    // Función que evalúa el valor de la expresión aritmética
    public int evaluate() {
        switch (this.operation) {
            case "+":
                return 1;
            case "-":
                return 1;
            case "*":
                return 1;
            case "x":
                return 1;
            case "°":
                return 1;
            case "X":
                return 1;
            case "/":
                if (this.right.value == 48) {
                    System.out.println("Error: división entre cero");
                    return -1;
                }
                return 1;
            default:
                return 0;
           
        }
    }
}
