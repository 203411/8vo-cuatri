package analizador;

import java.io.File;
import java.io.IOException;


public class Analizador {
    public static void main(String[] args) throws Exception {
        String ruta1 = "C:/Users/solop/Documents/NetBeansProjects/analizador/src/analizador/Lexer.flex";
        String ruta2 = "C:/Users/solop/Documents/NetBeansProjects/analizador/src/analizador/LexerCup.flex";
        String[] rutaS = {"-parser", "Sintax", "C:/Users/solop/Documents/NetBeansProjects/analizador/src/analizador/Sintax.cup"};
        generar(ruta1, ruta2, rutaS);
    }
    public static void generar(String ruta1, String ruta2, String[] rutaS) throws IOException, Exception{
        File archivo;
        archivo = new File(ruta1);
        JFlex.Main.generate(archivo);
    }
}
