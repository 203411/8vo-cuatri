/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package proyecto;

/**
 *
 * @author solop
 */
public enum Tokens {
    Linea,
    Create,
    Select,
    Insert,
    Update,
    Delete,
    Alter,
    Truncate,
    Database,
    Table,
    Column,
    From,
    Where,
    Drop,
    Into,
    Values,
    Set,
    If,
    Not,
    Exists,
    Varchar,
    Primary,
    Key,
    Foreign,
    Nulo,
    Add,
    Modify,
    Change,
    Rename,
    To,
    Referencia,
    Entero,
    Datetime,
    Boolean,
    Double,
    Parentesis_a, 
    Parentesis_c, 
    Coma, 
    P_coma,
    Asterisco,
    Igual,
    Mayor_que,
    Menor_que,
    Diferente_a, 
    Mayor_igual,
    Menor_igual,
    Punto,
    ID,
    Identificador,
    Numero,
    Datos,
    Error
    
}
