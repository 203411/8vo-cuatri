package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;

public class Conexion {
    //Se hace la conexion a la base de datos
    String bd = "prueba";
    String url = "jdbc:mysql://localhost:3306/";
    String user = "root";
    String password = "solis2002";
    String driver = "com.mysql.cj.jdbc.Driver";
    Connection cx;
    
    public Conexion(String bd) {
        this.bd = bd;
    }
    
    public Connection conectar(){
        try {
            Class.forName(driver);
            cx = DriverManager.getConnection(url+bd, user, password);
            System.out.println("Se conecto a base de datos "+bd);
        } catch (ClassNotFoundException | SQLException ex){
            System.out.println("No se conecto a base de datos "+bd);
            //Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }
    
    public void desconectar(){
        try {
            cx.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void ejecutarSentencia(String sentencia){
        try {
            Statement statement = cx.createStatement();
            String resultStr;
            String sqlType = sentencia.trim().toUpperCase().split("\\s+")[0]; // Obtiene la primera palabra de la cadena
            
            switch (sqlType) {
                case "SELECT" -> {
                    ResultSet result = statement.executeQuery(sentencia);
                    
                    StringBuilder resultStrBuilder = new StringBuilder();
                    while (result.next()) {
                        String column1 = result.getString("column1");
                        int column2 = result.getInt("column2");
                        resultStrBuilder.append("column1: ").append(column1).append(", column2: ").append(column2).append("\n");
                    }
                    
                    resultStr = resultStrBuilder.toString();
                }
                case "INSERT", "UPDATE", "DELETE" -> {
                    int result = statement.executeUpdate(sentencia);
                    resultStr = Integer.toString(result);
                }
                default -> {
                    boolean result = statement.execute(sentencia);
                    resultStr = Boolean.toString(result);
                }
            }
            System.out.println("Resultado: \n"+resultStr);
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args){
        Conexion conexion = new Conexion("prueba"); //recibe la base de datos
        conexion.conectar();
        conexion.ejecutarSentencia("CREATE DATABASE prueba2");
        conexion.ejecutarSentencia(
                "CREATE TABLE prueba2.usuarios (" +
                "    id INT PRIMARY KEY," +
                "    nombre VARCHAR(50)," +
                "    apellido VARCHAR(50)," +
                "    email VARCHAR(100)," +
                "    edad INT" +
                ");"
        );
        conexion.ejecutarSentencia(
                "INSERT INTO prueba2.usuarios (id, nombre, apellido, email, edad)" +
                "VALUES (1, 'Juan', 'Pérez', 'juanperez@example.com', 35);"
        );
        
        /*
        NOTA: Se pueden hacer sentencias a cualquier base de datos una vez hecha la conexion
        
        para ejecutar sentencias en varias lineas usa:
            "Sentencia linea 1" + "sentencia linea 2"
        para ejecutar sentencias en una sola linea usa:
            "sentencia"
        */
    }
}
