
package analizador;
//import static analizador.Token;
import java.io.File;


public class Analizador {

    public static void main(String[] args) {
        //String path = "C:/Users/solop/Documents/NetBeansProjects/analizador/src/analizador/Lexer.flex";
        //generarLexer(path);

    }

    public static void generarLexer(String path) {
       File file = new File(path);
       JFlex.Main.generate(file);
    }
    
}
