/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

public enum Tokens {
    Linea,
    Igual,
    Suma,
    Resta,
    Mayor_que,
    Menor_que,
    Parentesis_a,
    Parentesis_c,
    Llave_a,
    Llave_c,
    Corchete_a,
    Corchete_c,
    P_coma,
    Punto,
    Guion,
    Identificador,
    Producto,
    Numero,
    Precio,
    Cantidad,
    Cliente_a,
    Cliente_c,
    Diagonal,
    Comillas,
    ERROR
}
