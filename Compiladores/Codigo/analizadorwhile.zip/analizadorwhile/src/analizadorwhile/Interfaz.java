/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analizadorwhile;

import java.awt.Color;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java_cup.runtime.Symbol;

public class Interfaz extends javax.swing.JFrame {

    /**
     * Creates new form FrmPrincipal
     */
    public Interfaz() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    String texto;
    List<datos> tokenlist;
    
    private void analizarLexico() throws IOException{
        int cont = 1;
        tokenlist = new LinkedList<datos>();
        String expr = (String) txtResultado.getText();
        Lexer lexer = new Lexer(new StringReader(expr));
        texto = txtResultado.getText();
        
        while (true) {
            Tokens token = lexer.yylex();
            if(token==null){
               
                return;
            }
            datos tokenItem = new datos();
            switch (token) {
                case Identificador:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "X";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = "";
                    break;
                case Simbolo:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Parentesis_a: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Parentesis_c: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Llave_a: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Llave_c: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Punto: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case P_coma: 
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Mayor_que:tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                case Menor_que:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "X";
                    tokenItem.tipo = "";
                    break;
                
                case Entero:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "X";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = ""+token;
                    break;
                case Float:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "X";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = ""+token;
                    break;
                case String:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "X";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = ""+token;
                    break;
                case While:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "X";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = "";
                    break;
                case Imprimir:
                    tokenItem.token = lexer.lexeme;
                    tokenItem.pr = "X";
                    tokenItem.identificador = "";
                    tokenItem.cadena = "";
                    tokenItem.numero = "";
                    tokenItem.simbolo = "";
                    tokenItem.tipo = "";
                    break;
                
                
            }
            tokenlist.add(tokenItem);
        }
    }

    private void analizarSemantico() throws IOException{
        int cont = 1;
        
        String expr = (String) txtResultado.getText();
        Lexer lexer = new Lexer(new StringReader(expr));
        String resultado = "";
        jTextArea1.setForeground(new Color(0, 0, 255));
        while (true) {
            Tokens token = lexer.yylex();
            if (token == null) {
                jTextArea1.setText(resultado);
                return;
            }
            switch (token) {
                case Linea:
                    cont++;
                    resultado += "\nLINEA "+ cont + "\n\n";   
                    break;
                    
                case While:
                    resultado += "  Se declara condición\n";
                    break;
                    
                case Parentesis_a:
                    resultado += "  Inicia condición\n";
                    break;   
                    
                case Mayor_que:
                    resultado += "  Operador\n";
                    break;   
                case Menor_que:
                    resultado += "  Operador\n";
                    break;   
                    
                    
                case Entero:
                    resultado += "  Valor\n";
                    break;   
                    
                case Imprimir:
                    resultado += "  Método\n";
                    break;   
                    
                case Parentesis_c:
                    resultado += "  Finaliza condición\n";
                    break;
                    
                case Llave_a:
                    resultado += "  Inicia declaración\n";
                    break;
                    
                case Llave_c:
                    resultado += "  Finaliza declaración\n";
                    break;
                    
                case P_coma:
                    resultado += "  Finaliza instrucción\n";
                    break;
                    
                case Identificador:
                    resultado += "  Nombre de variable\n";
                    break;
                    
                case String:
                    resultado += "  Cadena\n";
                    break;
                    
                default:
                    resultado += "  < " + lexer.lexeme + " >\n";
                    break;
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResultado = new javax.swing.JTextArea();
        btnAnalizarLex = new javax.swing.JButton();
        btnLimpiarLex = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAnalizarSin = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnAnalizarSin = new javax.swing.JButton();
        btnLimpiarSin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Analizador Lexico", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        txtResultado.setColumns(20);
        txtResultado.setRows(5);
        jScrollPane1.setViewportView(txtResultado);

        btnAnalizarLex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnAnalizarLex.setText("Analizar");
        btnAnalizarLex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarLexActionPerformed(evt);
            }
        });

        btnLimpiarLex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnLimpiarLex.setText("Limpiar");
        btnLimpiarLex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarLexActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Código");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Token", "PR", "IDENTI", "CADENA", "NUMERO", "SIMBOLO", "TIPODATO"
            }
        ));
        jScrollPane4.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAnalizarLex))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(btnLimpiarLex)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnalizarLex)
                    .addComponent(btnLimpiarLex)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(208, 208, 208))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Analizador Sintactico", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        txtAnalizarSin.setEditable(false);
        txtAnalizarSin.setColumns(20);
        txtAnalizarSin.setRows(5);
        jScrollPane3.setViewportView(txtAnalizarSin);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Analiizador semantico", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnAnalizarSin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnAnalizarSin.setText("Analizar");
        btnAnalizarSin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarSinActionPerformed(evt);
            }
        });

        btnLimpiarSin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnLimpiarSin.setText("Limpiar");
        btnLimpiarSin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarSinActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAnalizarSin))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpiarSin, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(6, 6, 6))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnalizarSin)
                    .addComponent(btnLimpiarSin))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLimpiarLexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarLexActionPerformed
        // TODO add your handling code here:
        txtResultado.setText(null);
        DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.fireTableDataChanged();
    }//GEN-LAST:event_btnLimpiarLexActionPerformed

    private void btnLimpiarSinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarSinActionPerformed
        // TODO add your handling code here:
        txtAnalizarSin.setText(null);
        jTextArea1.setText(null);
    }//GEN-LAST:event_btnLimpiarSinActionPerformed

    private void btnAnalizarLexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarLexActionPerformed
        try {
            analizarLexico();
        } catch (IOException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }
        tablaResultado();
    }//GEN-LAST:event_btnAnalizarLexActionPerformed

    private void tablaResultado() {
        Object[][] matriz;
        matriz = new Object [tokenlist.size()][7];
        for(int i =0; i<tokenlist.size();i++){
            matriz[i][0] = tokenlist.get(i).token;
            matriz[i][1] = tokenlist.get(i).pr;
            matriz[i][2] = tokenlist.get(i).identificador;
            matriz[i][3] = tokenlist.get(i).cadena;
            matriz[i][4] = tokenlist.get(i).numero;
            matriz[i][5] = tokenlist.get(i).simbolo;
            matriz[i][6] = tokenlist.get(i).tipo;
        }
        
        jTable1.setModel(new javax.swing.table.DefaultTableModel(matriz,
            new String [] {
               "Token", "PR", "IDENTIFICADOR","CADENA","NUMERO","SIMBOLO","TIPO_DATO"
        }
        ));
    }
    
    private void btnAnalizarSinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarSinActionPerformed
        // TODO add your handling code here:
        String ST = txtResultado.getText();
        Sintax s = new Sintax(new analizadorwhile.LexerCup(new StringReader(ST)));
        
        try {
            s.parse();
            txtAnalizarSin.setText("Analisis realizado correctamente");
            txtAnalizarSin.setForeground(new Color(25, 150, 61));
            try {
                analizarSemantico();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE,null,ex);
            }
            
            ST = jTextArea1.getText();
            s = new Sintax(new analizadorwhile.LexerCup(new StringReader(ST)));
            
        } catch (Exception ex) {
            Symbol sym = s.getS();
            txtAnalizarSin.setText("Error de sintaxis. Linea: " + (sym.right + 1) + " Columna: " + (sym.left + 1) + ", Texto: \"" + sym.value + "\"");
            txtAnalizarSin.setForeground(Color.red);
            jTextArea1.setText("Error semantico");
            jTextArea1.setForeground(Color.red);
        }
    }//GEN-LAST:event_btnAnalizarSinActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnalizarLex;
    private javax.swing.JButton btnAnalizarSin;
    private javax.swing.JButton btnLimpiarLex;
    private javax.swing.JButton btnLimpiarSin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea txtAnalizarSin;
    private javax.swing.JTextArea txtResultado;
    // End of variables declaration//GEN-END:variables

    
}
