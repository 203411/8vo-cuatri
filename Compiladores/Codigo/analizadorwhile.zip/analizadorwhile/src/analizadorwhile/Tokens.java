/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.Tokens to edit this template
 */
package analizadorwhile;

/**
 *
 * @author solop
 */
public enum Tokens {
    While,
    Imprimir,
    Identificador,
    Entero, 
    Simbolo,
    Float,
    String,
    Mayor_que,
    Menor_que,
    Parentesis_a,
    Parentesis_c,
    Llave_a,
    Llave_c,
    P_coma,
    Punto,
    Linea,
    Error
    
}
